var math_module = require('./math')();
math_module.add(3,2);
math_module.multiply(3,2);
math_module.square(5);
math_module.random(3,60);
